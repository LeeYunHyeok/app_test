package com.example.notice

class Notice(val no_title:String, val no_reason:String, val no_num:String, val no_date:String, val no_person:String)